[ls] Print current directory path
[ls -a] List all the files from the current directory including the hidden ones
[ls -R] Now list all the files inside the workspace, recursively (all files in the hierarchy).
[cd, cat] Go to the last level below the small-name folder and write in the console the content of the trophy.txt file.
[cd ls] Move back to the root and get List all files with the javascript tipical extension
[mkdir] create a new folder inside funcode/the-most-funny/ called "not-that-funny".
[mv, cp] Create a copy of the last file you can vinde below the /boringfolder/ childs (the-mostboding-text.txt)
[rmdir] remove the "remove-me" folder from the funcode directory 
[cd, cat] print in the screen the-ultimate-joke.txt
[rm] remove all the contents form the boringfolder, the are extremly boring.