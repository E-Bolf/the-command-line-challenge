Where do you put Vegeta after you kill him? In the Frieza. 

What did Beerus say to Goku? Why don't you tell your son to "Gohan" home. 

How many Super Saiyans does it take to change a light bulb? Just one, but it will take him five episodes.

I don't find Dragon Ball Z jokes to be funny..... "Just Saiyan" 

What do Saiyans wear to the beach? Trunks. 

What did Vegeta say when he got his tuition bill? "It's over 9000" 

Where does Vegeta get the energy to fly? Red Bullma, it gives you wings. 

What is Goku's favorite instrument of destruction? A Piccolo (flute). 

How do you get in touch with an android? By using a CELL Phone. 

Did you know Frieza wasn't very popular in school? His brother was COOLER. 

Me: How do you make Dragon Ball Z less gay? Shenron: "Your wish is far beyond my power." 

What does an elite saiyan warrior need to fix a car? Nappa know how. 

I cut off a monkeys tail and now he's just a vegeta-ble. 

Hey, Vegeta I heard you have a hole in your Trunks. -Cell 

source: http://www.jokes4us.com/peoplejokes/dragonballzjokes.html